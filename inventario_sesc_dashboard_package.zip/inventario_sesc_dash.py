
import pandas as pd
import plotly.express as px
from dash import Dash, dcc, html, Input, Output, dash_table

xls = pd.ExcelFile("Relatório Conclusivo SESC Administração Central (1).xlsx", engine="openpyxl")
abas = xls.sheet_names

def preparar_dados():
    dados = {}
    for aba in abas:
        df = xls.parse(aba, skiprows=2)
        df.dropna(how="all", inplace=True)
        df.columns = [str(col).strip() for col in df.columns]
        dados[aba] = df
    return dados

app = Dash(__name__)
app.title = "Inventário Patrimonial - SESC"

app.layout = html.Div([
    html.H1("Inventário Patrimonial - Administração Central do SESC", style={"textAlign": "center"}),
    html.Hr(),
    html.Div([
        html.Label("Selecione a aba da planilha:"),
        dcc.Dropdown(id="aba-dropdown", options=[{"label": aba, "value": aba} for aba in abas], value=abas[0])
    ], style={"width": "40%", "margin": "auto"}),
    html.Br(),
    html.Div(id="graficos"),
    html.Hr(),
    html.H3("Relatório Conclusivo"),
    html.P("Este painel interativo apresenta uma visão abrangente do inventário patrimonial do SESC Administração Central, permitindo a análise por unidade organizacional, valor, localização, tipo e outros critérios relevantes.")
])

@app.callback(
    Output("graficos", "children"),
    Input("aba-dropdown", "value")
)
def atualizar_graficos(aba):
    df = preparar_dados()[aba]
    graficos = []

    if "UO" in df.columns:
        contagem_uo = df["UO"].value_counts().reset_index()
        contagem_uo.columns = ["UO", "Quantidade"]
        fig1 = px.bar(contagem_uo, x="UO", y="Quantidade", title="Itens por Unidade Organizacional")
        graficos.append(dcc.Graph(figure=fig1))

    if "VALOR" in df.columns:
        df["VALOR"] = pd.to_numeric(df["VALOR"], errors="coerce")
        valor_uo = df.groupby("UO")["VALOR"].sum().reset_index()
        fig2 = px.pie(valor_uo, names="UO", values="VALOR", title="Distribuição de Valor por UO")
        graficos.append(dcc.Graph(figure=fig2))

    if "AQUISIÇÃO" in df.columns:
        df["AQUISIÇÃO"] = pd.to_datetime(df["AQUISIÇÃO"], errors="coerce")
        df["Ano"] = df["AQUISIÇÃO"].dt.year
        aquisicao_ano = df["Ano"].value_counts().sort_index().reset_index()
        aquisicao_ano.columns = ["Ano", "Quantidade"]
        fig3 = px.line(aquisicao_ano, x="Ano", y="Quantidade", title="Itens por Ano de Aquisição")
        graficos.append(dcc.Graph(figure=fig3))

    if "DESCRIÇÃO" in df.columns and "VALOR" in df.columns:
        top_valor = df[["DESCRIÇÃO", "VALOR"]].dropna()
        top_valor["VALOR"] = pd.to_numeric(top_valor["VALOR"], errors="coerce")
        top_valor = top_valor.sort_values(by="VALOR", ascending=False).head(10)
        fig4 = px.bar(top_valor, x="DESCRIÇÃO", y="VALOR", title="Top 10 Itens de Maior Valor")
        graficos.append(dcc.Graph(figure=fig4))

    if "LOCALIZAÇÃO" in df.columns:
        localizacao = df["LOCALIZAÇÃO"].value_counts().reset_index()
        localizacao.columns = ["Localização", "Quantidade"]
        fig5 = px.bar(localizacao.head(10), x="Localização", y="Quantidade", title="Top 10 Localizações")
        graficos.append(dcc.Graph(figure=fig5))

    if "VALOR" in df.columns:
        valor_zero = df[df["VALOR"].isna() | (df["VALOR"] == 0)]
        tabela = dash_table.DataTable(
            columns=[{"name": i, "id": i} for i in ["DESCRIÇÃO", "UO", "LOCALIZAÇÃO"] if i in valor_zero.columns],
            data=valor_zero.to_dict("records"),
            page_size=10
        )
        graficos.append(html.Div([html.H4("Itens com Valor Zero ou Nulo"), tabela]))

    if "TIPO" in df.columns:
        tipo_contagem = df["TIPO"].value_counts().reset_index()
        tipo_contagem.columns = ["Tipo", "Quantidade"]
        fig7 = px.pie(tipo_contagem, names="Tipo", values="Quantidade", title="Distribuição por Tipo")
        graficos.append(dcc.Graph(figure=fig7))

    if "MOTIVO DA TRANSFERÊNCIA" in df.columns:
        motivo_contagem = df["MOTIVO DA TRANSFERÊNCIA"].value_counts().reset_index()
        motivo_contagem.columns = ["Motivo", "Quantidade"]
        fig8 = px.bar(motivo_contagem, x="Motivo", y="Quantidade", title="Motivos de Transferência")
        graficos.append(dcc.Graph(figure=fig8))

    if "EMPRESA" in df.columns:
        empresa_contagem = df["EMPRESA"].value_counts().reset_index()
        empresa_contagem.columns = ["Empresa", "Quantidade"]
        fig9 = px.bar(empresa_contagem, x="Empresa", y="Quantidade", title="Itens por Empresa")
        graficos.append(dcc.Graph(figure=fig9))

    if "TERMO SIM OU NÃO" in df.columns:
        termo_contagem = df["TERMO SIM OU NÃO"].value_counts().reset_index()
        termo_contagem.columns = ["Termo", "Quantidade"]
        fig10 = px.pie(termo_contagem, names="Termo", values="Quantidade", title="Termos de Responsabilidade")
        graficos.append(dcc.Graph(figure=fig10))

    return graficos

if __name__ == "__main__":
    app.run_server(debug=False)
